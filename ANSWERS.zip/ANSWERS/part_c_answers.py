#!/usr/bin/python3.6
# This contains my answers for part C.
import asyncio
import aiosqlite
import sqlite3
from primefac import isPrime
import traceback
import time
from parts_ab_answers import prob1, prob2, prob3, prob3a, prob3b, prob5, prob6

async def get_rows(con, x, dirty_rows):
    '''Gets all the rows from the fake_sales database where agent_id equals x.
con: aiosqlite Connection object.
x: int, the value of agent_id to filter for.
Adds the rows found to dirty_rows, all the uncleaned data found so far'''
    # DO NOT CHANGE THIS FUNCTION
    await asyncio.sleep(0.05) # add a 50ms wait to simulate a slow connection
    cur = await con.execute("SELECT * FROM Sales WHERE agent_id = ?", (x,))
    dirty_rows.extend(await cur.fetchall())

def clean_sales(dirty_rows):
    '''Returns all rows from dirty_rows where the amount (third column) is prime
Returns: None'''
    # YOUR CODE HERE
    return [row for row in dirty_rows if not (isPrime(row[-1]) or row[-1] < 0)]

async def insert_clean_rows(con, clean_rows):
    '''Insert all of the rows in clean_rows into the database.
con: aiosqlite Connection object.'''
    # YOUR CODE HERE
    try:
        await con.executemany("INSERT INTO Clean_Sales(row_id,agent_id,agent,amount)"
                              + " VALUES (?,?,?,?)", clean_rows)
        return 1
    except Exception as ex:
        print(traceback.format_exc(ex))
        return 0

async def create_prime_db():
    '''
1. Create a new table, Clean_Sales(row_id INT, agent_id INT, agent TEXT, amount INT)
2. Using the get_rows function (and NO OTHER functions) to query the database,
    get every row in Sales.
3. After collecting all rows from Sales, make a new list of all rows where amount
    is a positive, non-prime number.
Don't forget to write your code so that the connection always closes, even if
    there's an error!'''
    # YOUR CODE HERE
    async with aiosqlite.connect("fake_sales.sqlite") as con:
        await con.execute("DROP TABLE IF EXISTS Clean_Sales")
        await con.execute("CREATE TABLE Clean_Sales(row_id INTEGER, agent_id INTEGER, agent TEXT, amount INTEGER)")
        await con.commit()
        tasks = []
        dirty_rows = []
        for agent_id in range(1, 21):
            task = asyncio.ensure_future(get_rows(con, agent_id, dirty_rows))
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions = True)
        clean_rows = clean_sales(dirty_rows)
        await insert_clean_rows(con, clean_rows)
        await con.commit()

def main():
    '''Get answers to problems 1-6 after using aiosqlite
    to create the database'''
    with sqlite3.connect("fake_sales.sqlite") as con:
        cur = con.cursor()
        cur.execute("SELECT * FROM Sales")
        dirty_sales = cur.fetchall()
        p1 = prob1(cur)
        print(f"prob1: {p1}")
        p2 = prob2(cur)
        print(f"prob2: {p2}")
        counts = prob3(cur)
        p3a = prob3a(counts)
        print(f"prob3a: {p3a}")
        p3b = prob3b(counts)
        print(f"prob3b: {p3b}")
        p5 = prob5(cur)
        print(f"prob5: {p5}")
        p6 = prob6(cur)
        print(f"prob6: {p6}")
        cur.close()
    con.close()
             
if __name__ == '__main__':
    t0 = time.perf_counter()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(create_prime_db())
    loop.close()
    print("time for asynchronous creation of clean_sales:", time.perf_counter() - t0)
    main()