#!/usr/bin/python3.6
# used to create the fake_sales.sqlite database
import random
import sqlite3

names = ['Betty', 'Brian', 'Bruce', 'Christine', 'Dominique', 
         'Gary', 'Jennifer', 'John', 'Karen', 'Larry', 'Lionel', 
         'Marie', 'Michelle', 'Mildred', 'Mindy', 'Ollie', 'Peter', 
         'Sally', 'Timothy', 'William']

def make_rows():
    random.seed(314159)
    rows = []
    for ii in range(999):
        id_ = ii//50+1
        rows.append([id_, names[id_-1], random.randint(-50,1000)])
    rows.append([20, names[19], random.randint(-50, 1000)])
    return rows

def main():
    '''Populate a CSV file and a SQLite database with a random string of primes
    '''
    rows = make_rows()
    with sqlite3.connect('fake_sales.sqlite') as con:
        cur = con.cursor()
        cur.execute("DROP TABLE IF EXISTS Sales")
        cur.execute("CREATE TABLE Sales(i INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, agent_id INTEGER, agent TEXT, amount INTEGER)")
        con.commit()
        start = 0
        end = 100
        while start < 1000:
            cur.executemany("INSERT INTO Sales(agent_id,agent,amount) VALUES (?,?,?)", rows[start:end])
            start = end
            end += 100
        con.commit()
                    
if __name__ == '__main__':
    main()