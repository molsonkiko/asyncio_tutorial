# this can be run in Hortonworks to set up the environment and run my
# answers to all of the problems
chmod +x *.py
echo "Setting up fake sales database and csv file"
./make_fake_sales.py
echo "Setting up sales_data json files"
./make_sales_data.py
echo "Answers to parts A and B"
./answers_partAB.py
echo "Answers to part C (should be same numbers as parts A and B)"
./async_db_access.py
echo "Answers to part D (see async_file_reading.py and questions.txt)"
./async_file_reading.py