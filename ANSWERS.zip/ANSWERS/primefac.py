import math

primes = [2, 3]
def isPrime(x):
    '''the good old Sieve of Eratosthenes.
The memoization of primes makes calculation essentially
    free for any primes smaller than the largest prime calculated in this
    session.'''
    maxprime = primes[-1]
    if x < 2 or (x > 2 and x % 2 == 0):
        return False
    if x <= maxprime:
        if x in primes:
            return True
        return False
    for p in primes:
        if x % p == 0:
            return False
    sqrtx = int(math.sqrt(x)) + 2
    for ii in range(maxprime, sqrtx, 2):
        ii_prime = True
        for p in primes:
            if ii % p == 0:
                ii_prime = False
                break
        if ii_prime:
            primes.append(ii)
            if x % ii == 0:
                return False
    return True