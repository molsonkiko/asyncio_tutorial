#!/usr/bin/python3.6
import sqlite3
import string
from primefac import isPrime
import time

def prob1(cur):
    cur.execute("SELECT COUNT(*) FROM Sales")
    return cur.fetchone()

def prob2(cur):
    cur.execute("SELECT COUNT(DISTINCT agent_id) FROM Sales")
    return cur.fetchone()

def prob3(cur):
    cur.execute("SELECT agent, COUNT(*) ct FROM Sales GROUP BY agent")
    counts = dict(cur.fetchall()) # dict mapping agent names to row counts
    fchar_counts = {}
    for agent, ct in counts.items():
        fchar_counts.setdefault(agent[0], 0)
        fchar_counts[agent[0]] += ct
    return fchar_counts

def prob3a(fchar_counts):
    return max(fchar_counts.items(), key = lambda x: x[1])

def prob3b(fchar_counts):
    return set(string.ascii_uppercase) - set(fchar_counts)

def get_clean_sales(cur):
    cur.execute("SELECT * FROM Sales WHERE amount >= 0")
    positive_rows = cur.fetchall()
    return [row for row in positive_rows if not isPrime(row[-1])]

def write_clean_sales(cur, con, clean_sales):
    cur.execute("DROP TABLE IF EXISTS Clean_Sales")
    cur.execute("CREATE TABLE Clean_Sales(row_id INTEGER, agent_id INTEGER, agent TEXT, amount INTEGER)")
    con.commit()
    cur.executemany("INSERT INTO Clean_Sales(row_id,agent_id,agent,amount) VALUES (?,?,?,?)", clean_sales)
    # executemany repeats the command for all rows in an iterable.
    con.commit()

def prob5(cur):
    prob5_query = '''SELECT agent, tot_amount FROM (SELECT agent,
    SUM(amount) tot_amount
FROM Clean_Sales
GROUP BY agent
) agent_tots
ORDER BY tot_amount DESC
LIMIT 1
'''
    cur.execute(prob5_query)
    return cur.fetchone()

def prob6(cur):
    prob6_query = '''SELECT agent,
    tot_amount_clean/tot_amount_dirty clean_dirty_ratio
FROM (SELECT * FROM (SELECT agent, SUM(amount*1.0) tot_amount_clean
    FROM Clean_Sales GROUP BY agent) c JOIN
(SELECT agent, SUM(amount*1.0) tot_amount_dirty FROM Sales GROUP BY agent) d
ON c.agent = d.agent) ratios
ORDER BY clean_dirty_ratio DESC
LIMIT 1
'''
    # this would be MUCH more readable with common table expressions
    # but it seems that the version of sqlite supported by Python 3.6 doesn't
    # support CTEs, and our Hortonworks instances have Python 3.6.8.
    # sqlite3 for Python 3.9 (and possibly 3.7 or 3.8) supports CTEs.
    cur.execute(prob6_query)
    return cur.fetchone()

def main():
    with sqlite3.connect("fake_sales.sqlite") as con:
        cur = con.cursor()
        cur.execute("SELECT * FROM Sales")
        dirty_sales = cur.fetchall()
        p1 = prob1(cur)
        print(f"prob1: {p1}")
        p2 = prob2(cur)
        print(f"prob2: {p2}")
        counts = prob3(cur)
        p3a = prob3a(counts)
        print(f"prob3a: {p3a}")
        p3b = prob3b(counts)
        print(f"prob3b: {p3b}")
        t0 = time.perf_counter()
        clean_rows = get_clean_sales(cur)
        write_clean_sales(cur, con, clean_rows)
        print(f"Time for synchronous creation of clean_sales: {time.perf_counter() - t0}")
        p5 = prob5(cur)
        print(f"prob5: {p5}")
        p6 = prob6(cur)
        print(f"prob6: {p6}")
        cur.close()
    con.close()

if __name__ == '__main__':
    main()