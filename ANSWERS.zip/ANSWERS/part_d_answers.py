#!/usr/bin/python3.6
import asyncio
from aiofile import async_open
import os
import json
import re
import sqlite3

# this contains my answers for part D.
async def load_sales_json(fname):
    async with async_open(fname) as af:
        txt = await af.read()
    return json.loads(txt)

def parse_sales_json(j, multipliers):
    '''Process a JSON file as described in part D of questions.txt and return
    a 2-tuple:
    (the name of the agent, [list of integers, the total amount for each day])
    '''
    # YOUR CODE HERE
    name = j['agent']
    amounts = []
    for sales in j['sales']:
        day = sales['day']
        mult = multipliers[day]
        tot_amt = 0
        has_valid_amounts = False
        for amt in sales['amounts']:
            if amt >= 0: # ignore negative amounts
                tot_amt += amt
                has_valid_amounts = True
        if has_valid_amounts: # ignore days with no valid entries
            amounts.append(int(tot_amt * mult))
    return name, amounts

def write_sales(con, agent_id, name, amounts):
    '''Using a SQLite database connection, write the amounts sold to the
    Sales table.
con: as sqlite3 Connection object returned by sqlite3.connect(db fname)
agent_id: the agent_id of an agent, found in the name of the file.
name: the agent's name
amounts: the amount sold on each day
    '''
    for amt in amounts:
        con.execute("INSERT INTO Sales(agent_id, agent, amount) VALUES (?,?,?)", (agent_id, name, amt))
    con.commit()

def main():
    tasks = []
    agent_ids = []
    with open("sales_data/multipliers.json") as f:
        multipliers = json.load(f)
    
    for fname in os.listdir('sales_data'):
        if 'multipliers' in fname:
            continue
        agent_ids.append(int(re.findall('\d+', fname)[0]))
        tasks.append(load_sales_json(os.path.join('sales_data', fname)))
    scheduled_tasks = asyncio.gather(*tasks)
    loop = asyncio.get_event_loop()
    all_jsons = loop.run_until_complete(scheduled_tasks)
    loop.close()
    with sqlite3.connect("fake_sales.sqlite") as con:
        for agent_id, sales_json in zip(agent_ids, all_jsons):
            name, amounts = parse_sales_json(sales_json, multipliers)
            write_sales(con, agent_id, name, amounts)
        cur = con.execute("SELECT DISTINCT agent FROM Sales WHERE agent_id > 20")
        print("Agents with agent_id > 20:", cur.fetchall())
        # there should be 7 names: ['Cecilia', 'Duane', 'Eva', 'Kenneth', 
        # 'Pablo', 'Shirlee', 'Tami'] though not necessarily in that order
        cur = con.execute("SELECT COUNT(*) FROM Sales WHERE agent_id > 20 AND amount < 0")
        # this should be 0, because we should have filtered out all negative
        # amounts in the input JSON files
        print("Rows with agent_id > 20 and amount < 0:", cur.fetchone())
        
if __name__ == '__main__':
    main()