#!/usr/bin/python3.6
# used to make all the JSON files in the sales_data directory
import json
import random
import os

newnames = ['Cecilia', 'Duane', 'Eva', 'Kenneth', 'Pablo', 'Shirlee', 'Tami']

weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
            'Saturday', 'Sunday']

def main():
    if not os.path.exists('sales_data'):
        os.mkdir('sales_data')
    with open('sales_data/multipliers.json', 'w') as f:
        multipliers = {}
        for day in weekdays[:5]:
            multipliers[day] = 1
        for day in weekdays[5:]:
            multipliers[day] = 1.5
        json.dump(multipliers, f, indent = 4)
    random.seed(271828)
    for id_, name in enumerate(newnames):
        agent_id = 21 + id_
        sales = {'agent': name, 'sales': []}
        for ii in range(50):
            day = weekdays[ii % 7]
            sales['sales'].append({'day': day, 'amounts': []})
            num_sales = random.randint(1, 6)
            if ii % 7 < 5:
                num_sales *= 2 # more sales on weekdays
            for jj in range(num_sales):
                sales['sales'][ii]['amounts'].append(random.randint(-25, 75))
        with open(f'sales_data/agent{agent_id}_sales.json', 'w') as f:
            json.dump(sales, f, indent = 4)

if __name__ == '__main__':
    main()